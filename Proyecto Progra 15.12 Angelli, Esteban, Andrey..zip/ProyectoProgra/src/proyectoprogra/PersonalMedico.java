
package proyectoprogra;

import javax.swing.JOptionPane;

public class PersonalMedico {
    
    RegistroPersonalM personal[]=new RegistroPersonalM[1];
    
    public void registroDoctores(){
       int x;
       for (x=0;x<personal.length;x++){
           RegistroPersonalM m=new RegistroPersonalM ();
           
        m.setNombre(JOptionPane.showInputDialog(null,
                "Digite su nombre:"));
        m.setApellido(JOptionPane.showInputDialog(null, 
                "Digite su apellido:"));
        m.setID(JOptionPane.showInputDialog(null, 
                "Digite su ID:"));
        m.setCargo(JOptionPane.showInputDialog(null, 
                "Digite el cargo que desempena: "));
        m.setEspecialidad(JOptionPane.showInputDialog(null, 
                "Digite su especialidad:"));
        m.setTurno(JOptionPane.showInputDialog(null, 
                "Digite la hora del turno que labora"));
        m.setSede(JOptionPane.showInputDialog(null, 
                "Digite el hospital en el cual trabajo: "));
        personal[x]=m;
      }     
    }
    
    public void mostrarPersonal(){
        int x;
        String s="";
        for(x=0;x<personal.length;x++){
            s=s+personal[x].getNombre()+" "+personal[x].getApellido()+
                    " "+personal[x].getID()+" "+personal[x].getCargo()+
                    " "+personal[x].getEspecialidad()+" "+personal[x].getTurno()+" "+personal[x].getSede()+"\n";
        }
        JOptionPane.showMessageDialog(null, "Personal medico del Hospital:\n"+s);

    }
}


