
package proyectoprogra;

import javax.swing.JOptionPane;

public class HospiCorrespondiente extends RazonConsulta {
 String Nombre;
int edad;
 
 public void LeerDatos(){
     
     Nombre=JOptionPane.showInputDialog(null, "Ingrese su nombre: ");
     edad= Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese su edad: "));
     
     if (edad>=12) {
         
         JOptionPane.showMessageDialog(null, "Usted es mayor de edad, por favor dirijase al Hospital San Juan de Dios.");
         
     }
     if (edad<=12) {
         JOptionPane.showMessageDialog(null, "Usted es menor de edad, por favor dirijase al Hospinal Nacional de Niños con su encargado legal");
     }
   }
}