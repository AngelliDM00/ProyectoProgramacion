
package proyectoprogra;

public class RazonConsul {
    private String Nombre, cedula, tipoAccidente, lugarSuceso, tipoSangre;
   
    public void RazonConsul(){
        Nombre= "";
        cedula= "";
        tipoAccidente= "";
        tipoSangre= "";
        lugarSuceso= "";
        
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getTipoAccidente() {
        return tipoAccidente;
    }

    public void setTipoAccidente(String tipoAccidente) {
        this.tipoAccidente = tipoAccidente;
    }

    public String getLugarSuceso() {
        return lugarSuceso;
    }

    public void setLugarSuceso(String lugarSuceso) {
        this.lugarSuceso = lugarSuceso;
    }

    public String getTipoSangre() {
        return tipoSangre;
    }

    public void setTipoSangre(String tipoSangre) {
        this.tipoSangre = tipoSangre;
    }
    
}
