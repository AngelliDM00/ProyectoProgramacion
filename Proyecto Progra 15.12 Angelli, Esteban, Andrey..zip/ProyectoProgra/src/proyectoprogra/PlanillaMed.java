
package proyectoprogra;

import javax.swing.JOptionPane;

public class PlanillaMed {
    double salarioM=44452;
double salarioE=19700;
byte HorasTrabajadas;
private byte profesión;
double salario1;
String nombre;
double salario2;

public void Leerdatos(){
    
HorasTrabajadas=Byte.parseByte(JOptionPane.showInputDialog(null,"digite las horas trabajadas:"));
profesión=Byte.parseByte(JOptionPane.showInputDialog(null, "Porfavor, digite 1 si su profesión es medico o digite 2 si profesión es enfermer@:"));

if (profesión==1){
    
salario1= salarioM * HorasTrabajadas;
JOptionPane.showMessageDialog(null,"su salario es de: "+salario1);
}

if (profesión==2)
    
    salario2= salarioE * HorasTrabajadas;
JOptionPane.showMessageDialog(null, "Su salario es de: "+salario2);
        
}
}


