
package proyectoprogra;

import javax.swing.JOptionPane;

public class RazonConsulta {
    RazonConsul consulta=new RazonConsul();
    RegistroCitas paciente=new RegistroCitas();
    public void Consulta(){
        
        int opcion =0;
        
        do {
            opcion= Integer.parseInt(JOptionPane.showInputDialog(null, 
                    "1. Urgencia"
                  + "\n2. Cita control"
                  + "\n3. Cita programada\n0. Salir"));
        
            switch (opcion){
                case 1: {
                    llenarFormulario();break;
                }
                
                case 2: {
                    menu1();break;
                    
                }
                
                case 3: {

                    menu2();break;
            }
            
                case 4: {
                    System.exit(0);break;
                }
            }      
        }while (opcion !=0);
        
            
        }
 public void llenarFormulario(){
consulta.setNombre(JOptionPane.showInputDialog(null, "Digite su nombre y la del paciente: "));
consulta.setCedula(JOptionPane.showInputDialog(null, "Digite su cedula y la del paciente: "));
consulta.setTipoSangre(JOptionPane.showInputDialog(null, "Digite el tipo de sangre del paciente: "));
consulta.setTipoAccidente(JOptionPane.showInputDialog(null, "Digite el tipo de accidente: "));
consulta.setLugarSuceso(JOptionPane.showInputDialog(null, "Digite el lugar del suceso: "));


}
 public void menu1(){
     paciente.almacenarInformación5();
    
    
 }
 public void menu2(){
     paciente.citaPaciente();
 }
}