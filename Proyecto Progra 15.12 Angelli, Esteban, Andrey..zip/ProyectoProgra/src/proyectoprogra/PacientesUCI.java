
package proyectoprogra;

import javax.swing.JOptionPane;

public class PacientesUCI {
    
    private InfoUCI pacie[][]=new InfoUCI [1][6];
    
    public void llenarInfopaci(){
        int x, y;
        for(x=0;x<1;x++){
            for(y=0;y<6;y++){
                InfoUCI paci=new InfoUCI();
                
                paci.setNombre(JOptionPane.showInputDialog(null, "Digite el nombre del paciente: "));
                paci.setCedula(JOptionPane.showInputDialog(null, "Digite el numero de cedula del paciente: "));
                paci.setEdad(JOptionPane.showInputDialog(null, "Digite la edad del paciente: "));
                paci.setGenero(JOptionPane.showInputDialog(null, "Digite la edad del paciente: "));
                paci.setTipoSangre(JOptionPane.showInputDialog(null, "Digite el tipo de sangre del paciente: "));
                paci.setTipoEnfermedad(JOptionPane.showInputDialog(null, "Digite el tipo de enfermedad del paciente: "));
                pacie[x][y]=paci;
            }
        }
    }
    
    public void MostrarInfoP(){
        int x, y;
        String s= " ";
          for(x=0;x<1;x++){
            for(y=0;y<6;y++){
                
                s=s+pacie[x][y]+" ";
                
            }
            s=s+"\n";
         }
          JOptionPane.showMessageDialog(null, "Esta es la lista de pacientes en UCI: \n"+s);
         
    }
}
