
package proyectoprogra;

public class Main {
// Integrantes:
//Esteban Salas Marin
//Andrey Gonzalez Calderon
//Angelli Mora Granados
    
    public static void main(String[] args) {
         PersonalMedico m=new PersonalMedico();
         AccesoHospi p=new AccesoHospi();
         PlanillaMed l=new PlanillaMed();
         HospiCorrespondiente o=new HospiCorrespondiente();
         PacientesUCI q=new PacientesUCI();
    RegistroCitas r=new RegistroCitas();
    RazonConsulta n=new RazonConsulta();
    
     m.registroDoctores();
    m.mostrarPersonal();
    
    p.AceesoHospi();
    
    l.Leerdatos();
    
     o.LeerDatos();
     
     q.llenarInfopaci();
    q.MostrarInfoP();
    
    r.citaPaciente();
    r.almacenarInformación1();
    r.almacenarInformación2();
    r.almacenarInformación3();
    r.almacenarInformación4();
    r.almacenarInformación5();
    r.almacenarInformación6();
    r.informaciónCita();
    
    n.Consulta();
    n.llenarFormulario();
    n.menu1();
    n.menu2();
    
    
       }
    
}
