
package proyectoprogra;

public class Main {
// Integrantes:
//Esteban Salas Marin
//Andrey Gonzalez Calderon
//Angelli Mora Granados
    
    public static void main(String[] args) {
         PersonalMedico m=new PersonalMedico();
         AccesoHospi p=new AccesoHospi();
         PlanillaMed l=new PlanillaMed();
    RegistroCitas r=new RegistroCitas();
    RazonConsulta n=new RazonConsulta();
    HospiCorrespondiente o=new HospiCorrespondiente();
    PacientesUCI q=new PacientesUCI();
    
     m.registroDoctores();
    m.mostrarPersonal();
    
    p.AceesoHospi();
    
    l.Leerdatos();
    
    r.citaPaciente();
    r.almacenarInformación1();
    r.almacenarInformación2();
    r.almacenarInformación3();
    r.almacenarInformación4();
    r.almacenarInformación5();
    r.almacenarInformación6();
    r.informaciónCita();
    
    n.Consulta();
    n.llenarFormulario();
    n.menu1();
    n.menu2();
    
    
    o.LeerDatos();
        
    q.llenarInfopaci();
    q.MostrarInfoP();
       }
    
}
