
package proyectoprogra;

public class InfoUCI {
    private PacientesUCI paci=new PacientesUCI();
    
     private String Nombre, cedula, tipoEnfermedad, tipoSangre, Edad, Genero;
     

    public InfoUCI() {
        Nombre = "";
        cedula = "";
        tipoEnfermedad = "";
        tipoSangre = "";
        Edad = "";
        Genero = "";
    }

    public PacientesUCI getPaci() {
        return paci;
    }

    public void setPaci(PacientesUCI paci) {
        this.paci = paci;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getTipoEnfermedad() {
        return tipoEnfermedad;
    }

    public void setTipoEnfermedad(String tipoEnfermedad) {
        this.tipoEnfermedad = tipoEnfermedad;
    }

    public String getTipoSangre() {
        return tipoSangre;
    }

    public void setTipoSangre(String tipoSangre) {
        this.tipoSangre = tipoSangre;
    }

    public String getEdad() {
        return Edad;
    }

    public void setEdad(String Edad) {
        this.Edad = Edad;
    }

    public String getGenero() {
        return Genero;
    }

    public void setGenero(String Genero) {
        this.Genero = Genero;
    }

}
