
package proyectoprogra;

import javax.swing.JOptionPane;

public class AccesoHospi extends PersonalMedico {
    
    public void AceesoHospi(){
        
        int x, encontrado=0;
        String personalbuscado;
    String s="";

    personalbuscado= JOptionPane.showInputDialog(null,
            "ingrese el personal que desea buscar");
    for (x=0;x<personal.length;x++){
        
     if (personalbuscado.equals(personal[x])){
     JOptionPane.showMessageDialog(null,"Estos son los datos encontrados .\n"
             + "**Acesso Permitido**");
     encontrado=1;
     
         } 
    }   
    if(encontrado==0){
    JOptionPane.showMessageDialog(null,"no se encontraron los datos del persona.\n"
            + "**Acesso Denegado**");
        }
    
    
    }
    
}

